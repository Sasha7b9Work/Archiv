#pragma once

namespace NS_TypesMath
{

    enum Function {
        Function_Addition,
        Function_Multiplication
    };

}