/****************************************************************************
** Meta object code from reading C++ file 'DisplayRegistrator.h'
**
** Created: Thu Jun 7 09:35:54 2012
**      by: The Qt Meta Object Compiler version 61 (Qt 4.5.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../src/DisplayRegistrator.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'DisplayRegistrator.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 61
#error "This file was generated using the moc from 4.5.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_DisplayRegistrator[] = {

 // content:
       2,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   12, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors

 // signals: signature, parameters, type, tag, flags
      20,   19,   19,   19, 0x05,

 // slots: signature, parameters, type, tag, flags
      42,   19,   19,   19, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_DisplayRegistrator[] = {
    "DisplayRegistrator\0\0SignalMoveSignal(int)\0"
    "SlotMoveSignal(int)\0"
};

const QMetaObject DisplayRegistrator::staticMetaObject = {
    { &QFrame::staticMetaObject, qt_meta_stringdata_DisplayRegistrator,
      qt_meta_data_DisplayRegistrator, 0 }
};

const QMetaObject *DisplayRegistrator::metaObject() const
{
    return &staticMetaObject;
}

void *DisplayRegistrator::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_DisplayRegistrator))
        return static_cast<void*>(const_cast< DisplayRegistrator*>(this));
    return QFrame::qt_metacast(_clname);
}

int DisplayRegistrator::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QFrame::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: SignalMoveSignal((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 1: SlotMoveSignal((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
        _id -= 2;
    }
    return _id;
}

// SIGNAL 0
void DisplayRegistrator::SignalMoveSignal(int _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_END_MOC_NAMESPACE
