//  [12/13/2009 Sasha]
#include "AlteraRegistrator.h"
#include "../../common/BinaryMathematics.h"
#include "../../common/TablesOfConverting.h"
#include <algorithm>

using namespace std;

using namespace NS_AlteraAddressSpace;
using namespace NS_BinaryMathematics;

extern TablesOfConverting tables;

//  [12/13/2009 Sasha]
AlteraRegistrator::AlteraRegistrator() : AbstractAltera() {
}

//  [12/13/2009 Sasha]
bool AlteraRegistrator::DataReady() {
    if(!running) {
        return false;
    }
    BYTE flag[8];
    bool readed = Read(READ_FL, 8, flag);
    static const int NUM_P = 1;
    if(readed && (GetBit(flag[0], 0))) {
        BYTE data0_0[NUM_P];
        BYTE data0_1[NUM_P];
        Read(READ_POINT_1, NUM_P, data0_0);
        Read(READ_POINT_1, NUM_P, data0_1);
        if(data0_0[0] != data0_1[0])
            cout << "data0 != " << data0_0[0] << " " << data0_1[0] << endl;
        data[0] = tables.GetAbsVoltage(data0_1[0], settings.GetRange(0), settings.GetRShift(0));

        BYTE data1_0[NUM_P];
        BYTE data1_1[NUM_P];
        Read(READ_POINT_2, NUM_P, data1_0);
        Read(READ_POINT_2, NUM_P, data1_1);
        if(data1_0[0] != data1_1[0])
            cout << "data1 != " << data1_0[0] << " " << data1_1[0] << endl;
        data[1] = tables.GetAbsVoltage(data1_1[0], settings.GetRange(1), settings.GetRShift(1));

        BYTE delta0 = MaxElem(data0_1, NUM_P) - MinElem(data0_1, NUM_P);
        BYTE delta1 = MaxElem(data1_1, NUM_P) - MinElem(data1_1, NUM_P);
        if((delta0 + delta1) != 0)
            cout << "delta1 = " << (int)delta0 << ", delta2 = " << (int)delta1 << endl;

        if(delta0 != 0 || delta1 != 0)
            for(int i = 0; i < NUM_P; i++)
                cout << (int)data0_1[i] << "   " << (int)data1_1[i] << endl;

        return true;
    }
    else {
        return false;
    }
}

//  [12/13/2009 Sasha]
double AlteraRegistrator::GetValue(int _channel) {
    return data[_channel];
}