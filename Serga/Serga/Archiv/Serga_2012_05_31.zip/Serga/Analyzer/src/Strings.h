//  [9/30/2009 Sasha]
#pragma once

#define TEXT_5mV "5mV"
#define TEXT_10mV "10mV"
#define TEXT_20mV "20mV"
#define TEXT_50mV "50mV"
#define TEXT_100mV "100mV"
#define TEXT_200mV "200mV"
#define TEXT_500mV "500mV"
#define TEXT_1V "1V"
#define TEXT_2V "2V"
#define TEXT_5V "5V"