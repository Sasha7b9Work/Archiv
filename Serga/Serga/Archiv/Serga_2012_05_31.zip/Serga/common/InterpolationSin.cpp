#define _USE_MATH_DEFINES
#include "InterpolationSin.h"

