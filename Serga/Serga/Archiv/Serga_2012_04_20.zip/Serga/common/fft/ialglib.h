/********************************************************************
Stub file for assembly optimized ALGLIB subroutines.
********************************************************************/
#ifndef IALGLIB_H
#define IALGLIB_H

#pragma warning(disable:4244)
#include "ap.h"
#pragma warning(default:4244)

#endif
