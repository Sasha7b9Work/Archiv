#pragma once
#include <QFile>
#include <iostream>

using namespace std;

#define LOG(x, y) D129_WriteToLog(x, y);
#define LOG_MSG(...) VaArgsToChar(__FILE__, __LINE__, __VA_ARGS__)

inline char *VaArgsToChar(char *_nameFile, int _numStr, char *_format, ...)
{
    char buffer[1024];
    va_list args;
    va_start(args, _format);
    vsprintf_s(buffer, 1024, _format, args);
    va_end(args);

    // ������ ����� ��������� �� ����� ������ � �������� �����
    int sizeName = lstrlenA(_nameFile);
    char *startSimbol = _nameFile;
    const int maxLength = 30;
    if(sizeName > maxLength)
    {
        startSimbol = _nameFile + sizeName - 1;
        startSimbol -= maxLength;
    }

    static char retBuffer[1024];
#pragma warning(disable:4996)
    sprintf(retBuffer, "%s - %s:%d\n", buffer, startSimbol, _numStr);
#pragma warning(default:4996)
    return retBuffer;
}

class Log
{
public:
    Log(char *_nameFile) : level(0), enableFile(false), enableConsole(false), hConsole(INVALID_HANDLE_VALUE)
    {
        file = new QFile(_nameFile);
        file->open(QIODevice::WriteOnly | QIODevice::Truncate | QIODevice::Text);
    };

    ~Log()
    {
        file->close();
        if(INVALID_HANDLE_VALUE != hConsole)
        {
            CloseHandle(hConsole);
            FreeConsole();
        };
    };

    inline void Enable(bool _enableFile, bool _enableConsole, int _level)
    {
        enableFile = _enableFile;
        enableConsole = _enableConsole;
        level = _level;

        /*
        if(enableConsole && (INVALID_HANDLE_VALUE == hConsole))
        {
            hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
            if(NULL == hConsole)
            {
                AllocConsole();
                hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
            }
        }
        */
    };

    inline void Write(int _level, char *_msg)
    {
        if(_level > level)
            return;

        if(enableFile)
        {
            file->write(_msg);
            file->flush();
        };

        if(enableConsole)
        {
            //DWORD d;
            //WriteConsoleA(hConsole, _msg, lstrlenA(_msg), &d, NULL);
            cout << _msg << endl;
        };
    };

private:
    QFile *file;
    int level;
    bool enableFile;
    bool enableConsole;
    HANDLE hConsole;
};