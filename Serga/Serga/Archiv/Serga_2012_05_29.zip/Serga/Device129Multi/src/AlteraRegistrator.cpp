//  [12/13/2009 Sasha]
#include "AlteraRegistrator.h"
#include "../../common/BinaryMathematics.h"
#include "../../common/TablesOfConverting.h"

using namespace NS_AlteraAddressSpace;
using namespace NS_BinaryMathematics;

extern TablesOfConverting tables;

//  [12/13/2009 Sasha]
AlteraRegistrator::AlteraRegistrator() : AbstractAltera() {

}

//  [12/13/2009 Sasha]
bool AlteraRegistrator::DataReady() {
    if(!running) {
        return false;
    }
    BYTE flag[8];
    bool readed = Read(READ_FL, 8, flag);
    if(readed && (GetBit(flag[0], 4))) {
        BYTE data0;
        Read(READ_CONTR1, 1, &data0);
        data[0] = tables.GetAbsVoltage(data0, settings.GetRange(0), settings.GetRShift(0));
        BYTE data1;
        Read(READ_CONTR2, 1, &data1);
        data[1] = tables.GetAbsVoltage(data1, settings.GetRange(1), settings.GetRShift(1));
        return true;
    }
    else {
        return false;
    }
}

//  [12/13/2009 Sasha]
double AlteraRegistrator::GetValue(int _channel) {
    return data[_channel];
}